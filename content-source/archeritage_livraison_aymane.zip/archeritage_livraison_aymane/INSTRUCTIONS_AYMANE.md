# Instructions d'Implémentation pour Aymane

Bonjour Aymane,

Ce dossier contient les contenus optimisés pour la refonte marketing du site Archeritage. L'objectif de ces modifications est de transformer le site d'une simple vitrine en un outil de génération de contacts (leads), en mettant en valeur l'expérience du gérant fondateur et en structurant mieux l'offre.

## 1. Corrections Critiques Immédiates
Avant toute chose, veuillez mettre à jour les coordonnées sur l'ensemble du site (Footer + Page Contact) :
- **Email** : contact@archeritage.ma
- **Téléphone** : 06 61 04 71 30
- **Adresse** : Rue Soumaya IMM 82 ÉTAGE 4 Appt N 16, Quartier Palmier, Maarif, Casablanca

## 2. Intégration des nouvelles pages HTML
Dans le dossier `pages/`, vous trouverez le code HTML optimisé à intégrer dans votre CMS ou votre code source :

- **`01_accueil.html`** : Remplace la page d'accueil actuelle. Ajoute une section de segmentation ("À qui s'adresse Archeritage ?") et une bannière pour capturer des emails.
- **`02_contact.html`** : Remplace la page de contact. Le formulaire est désormais qualifié (demande le type de projet) pour mieux préparer les rendez-vous.
- **`03_mentions_legales.html`** : Nouvelle page légale structurée. **Attention : vous devez remplir les champs entre crochets [À COMPLÉTER]** (ICE, RC, Hébergeur) avant la mise en ligne.
- **`04_references_etudes_de_cas.html`** : Remplace la page Références. La structure est modifiée pour raconter une histoire (Défi -> Approche) ce qui est beaucoup plus vendeur.

## 3. Mise en place du Lead Magnet (Génération de prospects)
Dans le dossier `lead_magnets/`, vous trouverez :
- **`01_landing_page_livre_blanc.html`** : Une nouvelle page à créer (ex: `/ressources/guide-valorisation-fonciere`). C'est une page de capture d'email.
- **Action requise** : Vous devrez connecter les formulaires (celui de l'accueil et celui de cette landing page) à un outil d'emailing (ex: Mailchimp, Brevo) ou configurer le backend pour que le gérant reçoive un email avec les coordonnées du prospect et que le prospect reçoive le PDF en retour.

## 4. Nettoyage
Veuillez supprimer l'ancienne page "Confidentialité" qui était vide (score de 2/10 lors de l'audit) ou la fusionner avec les Mentions Légales pour le moment, le temps de rédiger une vraie politique RGPD.

Bonne intégration !
