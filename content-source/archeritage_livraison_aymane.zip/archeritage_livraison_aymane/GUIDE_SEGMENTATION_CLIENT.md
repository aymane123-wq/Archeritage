# Guide de Segmentation Client pour Archeritage

## Objectif
Adapter le message et le parcours d'Archeritage à trois profils de clients distincts, chacun ayant des besoins, des préoccupations et des cycles de décision différents.

---

## 1. Segment 1 : Collectivités & Institutions Publiques

### Profil
- **Décideurs** : Élus locaux, directeurs de collectivités, responsables de projets urbains
- **Enjeux** : Gouvernance territoriale, impact économique et social, respect des délais et budgets publics
- **Cycle de décision** : Long (6-12 mois), impliquant plusieurs niveaux d'approbation
- **Budget** : Généralement disponible, mais soumis à appels d'offres

### Message clé
> "Transformez votre territoire en atout économique et culturel grâce à une gouvernance rigoureuse et une expertise éprouvée."

### Propositions de valeur
1. **Méthode PATRIGOV** : Gouvernance documentée et transparente pour les projets publics
2. **Expérience institutionnelle** : Références avec UNESCO, UNDP, Banque mondiale
3. **Gestion multi-acteurs** : Coordination des parties prenantes complexes

### Landing Page Recommandée
**URL** : `/pour-les-collectivites`

**Contenu clé** :
- Cas d'études de revitalisation urbaine (Tiznit, Tanger)
- Témoignage d'un élu ou directeur de collectivité
- Infographie de la méthode PATRIGOV
- CTA : "Demander une présentation de la méthode PATRIGOV"

### Lead Magnet Adapté
**Titre** : "Guide de gouvernance pour les projets territoriaux d'envergure"
**Contenu** : Checklist des 10 points critiques pour sécuriser un projet public complexe

---

## 2. Segment 2 : Investisseurs & Promoteurs Privés

### Profil
- **Décideurs** : PDG, directeurs de développement, responsables d'acquisitions foncières
- **Enjeux** : ROI, rentabilité, réduction des risques fonciers et réglementaires, time-to-market
- **Cycle de décision** : Moyen (3-6 mois), basé sur des analyses financières
- **Budget** : Limité aux études préalables, mais important pour les projets validés

### Message clé
> "Maximisez la valeur de vos terrains et réduisez les risques grâce à une expertise foncière et réglementaire inégalée."

### Propositions de valeur
1. **Optimisation parcellaire** : Augmentation de la densité et du rendement foncier
2. **Sécurisation réglementaire** : Anticipation des blocages légaux et administratifs
3. **Diagnostic préalable** : Réduction des risques avant investissement

### Landing Page Recommandée
**URL** : `/pour-les-investisseurs`

**Contenu clé** :
- Calculateur de valorisation foncière (outil interactif)
- Cas d'études d'optimisation parcellaire avec chiffres (ex. : +30% de densité)
- Témoignage d'un investisseur ou promoteur
- CTA : "Évaluer le potentiel de mon terrain"

### Lead Magnet Adapté
**Titre** : "Les 5 erreurs fatales dans la valorisation du foncier au Maroc"
**Contenu** : Analyse détaillée des pièges réglementaires et techniques, avec solutions

---

## 3. Segment 3 : Maîtres d'Ouvrage de Projets d'Envergure

### Profil
- **Décideurs** : Directeurs de projets, responsables de programmes, architectes mandataires
- **Enjeux** : Qualité architecturale, respect des délais, coordination multi-disciplinaire, gestion des risques
- **Cycle de décision** : Moyen (4-8 mois), basé sur des appels d'offres ou recommandations
- **Budget** : Significatif, justifié par la complexité du projet

### Message clé
> "Pilotez vos projets d'envergure avec une rigueur absolue et une vision architecturale forte."

### Propositions de valeur
1. **Coordination multi-acteurs** : Gestion intégrée des disciplines (architecture, structure, MEP, etc.)
2. **Gouvernance de projet** : Suivi documenté et transparent de l'avancement
3. **Expertise architecturale** : Conception de qualité adaptée aux enjeux territoriaux

### Landing Page Recommandée
**URL** : `/pour-les-maitres-douvrage`

**Contenu clé** :
- Cas d'études de projets complexes (équipements publics, bâtiments institutionnels)
- Méthodologie de pilotage Archeritage
- Témoignage d'un maître d'ouvrage ou architecte mandataire
- CTA : "Discuter de votre projet d'envergure"

### Lead Magnet Adapté
**Titre** : "Checklist de pilotage pour les projets architecturaux complexes"
**Contenu** : 15 points clés pour sécuriser la gouvernance et la qualité d'un projet d'envergure

---

## 4. Stratégie de Routage

### Flux d'acquisition recommandé

```
Visiteur arrive sur archeritage.ma
        ↓
Voit la section "À qui s'adresse Archeritage ?"
        ↓
Clique sur son profil (Collectivité / Investisseur / Maître d'ouvrage)
        ↓
Arrive sur landing page dédiée
        ↓
Télécharge le lead magnet adapté
        ↓
Remplit un formulaire qualifié
        ↓
Reçoit le PDF + Email de suivi personnalisé
        ↓
Le gérant d'Archeritage prépare un premier appel avec éléments concrets
```

### Formulaires qualifiés (par segment)

**Pour les Collectivités** :
- Nom de la collectivité
- Type de projet (urbain, patrimoine, infrastructure)
- Budget estimé
- Timeline

**Pour les Investisseurs** :
- Type de terrain (résidentiel, commercial, mixte)
- Localisation (quartier, ville)
- Surface
- Objectif (vente, développement, location)

**Pour les Maîtres d'Ouvrage** :
- Type de projet (équipement public, bâtiment institutionnel, etc.)
- Budget
- Timeline
- Disciplines impliquées

---

## 5. Contenu Éditorial par Segment

### Blog / Journal : Thèmes recommandés

**Pour les Collectivités** :
- "Comment la gouvernance territoriale sécurise les projets publics"
- "Cas d'étude : Revitalisation de la Médina de Fès"
- "PATRIGOV : Une méthode pour les villes en transition"

**Pour les Investisseurs** :
- "Valorisation foncière : Erreurs courantes et solutions"
- "Optimisation parcellaire : Augmenter la densité sans compromettre la qualité"
- "Sécuriser ses acquisitions foncières : Guide complet"

**Pour les Maîtres d'Ouvrage** :
- "Pilotage de projets complexes : Méthodes éprouvées"
- "Coordination multi-disciplinaire : Réduire les conflits et les retards"
- "Qualité architecturale et respect des délais : Concilier les deux"

---

## 6. Métriques de Succès par Segment

| Métrique | Collectivités | Investisseurs | Maîtres d'Ouvrage |
|----------|---------------|----------------|-------------------|
| Taux de conversion (Lead magnet) | 15-20% | 20-25% | 18-22% |
| Taux de conversion (Contact → RDV) | 30-40% | 40-50% | 35-45% |
| Cycle de vente moyen | 6-12 mois | 3-6 mois | 4-8 mois |
| Valeur moyenne du projet | €150k-500k | €50k-200k | €100k-400k |

---

## 7. Recommandations d'implémentation

1. **Créer les 3 landing pages** dédiées à chaque segment (URLs : `/pour-les-collectivites`, `/pour-les-investisseurs`, `/pour-les-maitres-douvrage`)
2. **Mettre en place les formulaires qualifiés** avec segmentation automatique
3. **Développer les lead magnets** adaptés à chaque profil
4. **Planifier le contenu éditorial** selon les thèmes recommandés
5. **Configurer le CRM** pour router automatiquement les leads vers le bon responsable

---

*Document préparé pour Aymane — Implémentation progressive recommandée*
